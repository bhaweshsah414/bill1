import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import com.capgemini.dao.QueryMapper;
import com.capgemini.exception.CustomersException;
import com.capgemini.util.DBConnection;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//INSERT INTO Customer VALUES(customer_Id_sequence.NEXTVAL,?,?,?,?,SYSDATE)";
		
	try{	
Connection con = DBConnection.getInstance().getConnection();	
		/*
		 * # File contains JDBC properties

dburl=jdbc:oracle:thin:localhost:1521:orcl11g
driver=oracle.jdbc.OracleDriver
username=lab1gtrg40
password=lab1goracle
*/
	
		 
		/* Class.forName("oracle.jdbc.OracleDriver");
		 
		Connection connection= DriverManager.getConnection("jdbc:oracle:thin:localhost:1521:xe","system","Capgemini123");*/
		//PreparedStatement preparedStatement=null;		
/*		ResultSet resultSet = null;
		
		Statement st = connection.createStatement();
		//int i=st.executeUpdate("INSERT INTO Customer VALUES(1,'name','45',23,'producti','4-Oct-2018')");
		System.out.println("before query");
		int i=st.executeUpdate("INSERT INTO Customer VALUES(10,'name','67',23,'producti','2-Mar-2018')");
		System.out.println("after query");
		System.out.println("rec inserted "+i);*/
		PreparedStatement ps=con.prepareStatement("select * from customer");  
		ResultSet rs=ps.executeQuery();  
		ResultSetMetaData rsmd=rs.getMetaData();  
		  
		System.out.println("Total columns: "+rsmd.getColumnCount());  
		System.out.println("Column Name of 1st column: "+rsmd.getColumnName(1));  
		System.out.println("Column Name of 2st column: "+rsmd.getColumnName(2));  
		System.out.println("Column Name of 1st column: "+rsmd.getColumnName(3));  
		System.out.println("Column Name of 1st column: "+rsmd.getColumnName(4));  
		System.out.println("Column Name of 1st column: "+rsmd.getColumnName(5));  
		System.out.println("Column Name of 1st column: "+rsmd.getColumnName(6));  
		System.out.println("Column Name of 1st column: "+rsmd.getColumnName(7));  
		System.out.println("Column Name of 1st column: "+rsmd.getColumnName(8));  
		System.out.println("Column Type Name of 1st column: "+rsmd.getColumnTypeName(1));  
		  	
		
	}catch(Exception e)
	{
		System.out.println(e.getMessage());
	}

		
	}

}
